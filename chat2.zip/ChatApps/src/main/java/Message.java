package za.ac.chatapps;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Message {

    // Message information
    private String MessageID;
    private String recipient;
    private String MessageText;
    private String MessageHash;

    // Keeps track of sent messages
    private static int totalMessages = 0;

    // Stores messages while the program is running
    private static List<message> sentMessages = new ArrayList<>();

    // Constructor
    public Message(String recipient, String MessageText) {
        this.MessageID = generateMessageID();
        this.recipient = recipient;
        this.MessageText = MessageText;
        this.MessageHash = createMessageHash();
    }

    // Generate a unique message ID
    private String generateMessageID() {
        return UUID.randomUUID().toString()
                .replace("-", "")
                .substring(0, 10);
    }

    // Check that Message ID is not more than 10 characters
    public boolean checkMessageID() {
        return MessageID != null && MessageID.length() <= 10;
    }

    // Check recipient cellphone number
    public boolean checkRecipientCell() {
        return recipient != null
                && recipient.length() <= 10
                && recipient.startsWith("+");
    }

    // Create the message hash
    public String createMessageHash() {

        String firstTwo;

        if (MessageText.length() >= 2) {
            firstTwo = MessageText.substring(0, 2).toUpperCase();
        } else {
            firstTwo = MessageText.toUpperCase();
        }

        String lastTwo;

        if (MessageText.length() >= 2) {
            lastTwo = MessageText.substring(MessageText.length() - 2)
                    .toUpperCase();
        } else {
            lastTwo = MessageText.toUpperCase();
        }

        MessageHash = firstTwo + ":" + totalMessages + ":" + lastTwo;

        return MessageHash;
    }

    // Send the message
    public String SentMessage() {

        totalMessages++;
        sentMessages.add(this);

        return "Message successfully sent.";
    }

    // Print all messages
    public String printMessages() {

        StringBuilder output = new StringBuilder();

        for (message msg : sentMessages) {

            output.append("Message ID: ")
                    .append(msg.MessageID)
                    .append("\n");

            output.append("Message Hash: ")
                    .append(msg.MessageHash)
                    .append("\n");

            output.append("Recipient: ")
                    .append(msg.recipient)
                    .append("\n");

            output.append("Message: ")
                    .append(msg.MessageText)
                    .append("\n\n");
        }

        return output.toString();
    }

    // Return total number of messages
    public int returnTotalMessages() {
        return totalMessages;
    }

    // Store message in JSON file
    public String storeMessage() {

        try {

            FileWriter writer = new FileWriter("messages.json", true);

            writer.write("{\n");
            writer.write("  \"messageID\": \"" + escapeJSON(MessageID) + "\",\n");
            writer.write("  \"messageHash\": \"" + escapeJSON(MessageHash) + "\",\n");
            writer.write("  \"recipient\": \"" + escapeJSON(recipient) + "\",\n");
            writer.write("  \"message\": \"" + escapeJSON(MessageText) + "\"\n");
            writer.write("}\n");

            writer.close();

            return "Message successfully stored.";

        } catch (IOException e) {

            return "Error storing message.";
        }
    }

    // Prevent quotation marks from breaking JSON
    private String escapeJSON(String text) {

        if (text == null) {
            return "";
        }

        return text.replace("\\", "\\\\")
                   .replace("\"", "\\\"");
    }

    // Getters
    public String getMessageID() {
        return MessageID;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return MessageText;
    }

    public String getMessageHash() {
        return MessageHash;
    }
}
    