package za.ac.chatapps;

import java.util.Scanner;

public class main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        Login login = new Login();

        System.out.println("Welcome to QuickChat.");

        // Login
        System.out.println("\nPlease log in to continue.");

        System.out.print("Enter username: ");
        String username = input.nextLine();

        System.out.print("Enter password: ");
        String password = input.nextLine();

        // Check login
        if (!login.loginUser(username, password)) {
            System.out.println("Login failed.");
            System.out.println("You cannot send messages.");
            return;
        }

        System.out.println("Login successful!");

        // Ask how many messages the user wants to send
        System.out.print("\nHow many messages would you like to enter? ");
        int numberOfMessages = input.nextInt();
        input.nextLine();

        int messagesSent = 0;

        // Main menu
        while (true) {

            System.out.println("\n----------------------------");
            System.out.println("QuickChat Menu");
            System.out.println("----------------------------");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Choose an option: ");

            int option = input.nextInt();
            input.nextLine();

            switch (option) {

                case 1:

                    if (messagesSent >= numberOfMessages) {
                        System.out.println("You have already entered the set number of messages.");
                        break;
                    }

                    System.out.print("Enter recipient cellphone number: ");
                    String recipient = input.nextLine();

                    // Check recipient
                    message tempMessage = new message(recipient, "");

                    if (!tempMessage.checkRecipientCell()) {
                        System.out.println("Invalid recipient cellphone number.");
                        break;
                    }

                    System.out.print("Enter your message: ");
                    String messageText = input.nextLine();

                    // Create the message
                    message newMessage =
                            new message(recipient, messageText);

                    // Check message ID
                    if (!newMessage.checkMessageID()) {
                        System.out.println("Invalid message ID.");
                        break;
                    }

                    // Create hash
                    newMessage.createMessageHash();

                    System.out.println("\nMessage created successfully.");
                    System.out.println("Message ID: "
                            + newMessage.getMessageID());
                    System.out.println("Message Hash: "
                            + newMessage.getMessageHash());

                    // Ask what to do with message
                    System.out.println("\nChoose what to do:");
                    System.out.println("1) Send Message");
                    System.out.println("2) Disregard Message");
                    System.out.println("3) Store Message");
                    System.out.print("Choose an option: ");

                    int messageOption = input.nextInt();
                    input.nextLine();

                    if (messageOption == 1) {

                        System.out.println(newMessage.SentMessage());
                        messagesSent++;

                    } else if (messageOption == 2) {

                        System.out.println("Message disregarded.");

                    } else if (messageOption == 3) {

                        System.out.println(newMessage.storeMessage());
                        messagesSent++;

                    } else {

                        System.out.println("Invalid option.");
                    }

                    break;

                case 2:

                    System.out.println("Coming Soon.");
                    break;

                case 3:

                    System.out.println("Thank you for using QuickChat.");
                    input.close();
                    return;

                default:

                    System.out.println("Invalid option. Please choose 1, 2 or 3.");
            }
        }
    }
}