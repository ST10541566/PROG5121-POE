package za.ac.chatapps;

public class Login {

    private String username;
    private String password;

    public Login() {
    }

    public Login(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Check username
    public boolean checkUsername() {
        return username != null
                && username.length() <= 5
                && username.contains("_");
    }

    // Check password
    public boolean checkPasswordComplexity() {
        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        for (int i = 0; i < password.length(); i++) {

            char c = password.charAt(i);

            if (Character.isUpperCase(c)) {
                hasCapital = true;
            }

            if (Character.isDigit(c)) {
                hasNumber = true;
            }

            if (!Character.isLetterOrDigit(c)) {
                hasSpecial = true;
            }
        }

        return hasCapital && hasNumber && hasSpecial;
    }

    // Register the user
    public String registerUser() {

        if (!checkUsername()) {
            return "Username is not correctly formatted.";
        }

        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted.";
        }

        return "User successfully registered.";
    }

    // Check login details
    public boolean loginUser(String enteredUsername, String enteredPassword) {

        return username != null
                && password != null
                && username.equals(enteredUsername)
                && password.equals(enteredPassword);
    }

    // Login status message
    public String returnLoginStatus(String enteredUsername,
                                     String enteredPassword) {

        if (loginUser(enteredUsername, enteredPassword)) {
            return "Login successful.";
        }

        return "Login failed.";
    }

    // Getters
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}