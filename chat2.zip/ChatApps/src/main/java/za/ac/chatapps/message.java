package za.ac.chatapps;

import java.util.Scanner;

public class main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("Welcome to QuickChat.");
        System.out.println();

        // Login details
        System.out.print("Enter username: ");
        String username = input.nextLine();

        System.out.print("Enter password: ");
        String password = input.nextLine();

        Login login = new Login(username, password);

        // For this Part 2 application,
        // the user must successfully log in.
        if (!login.loginUser(username, password)) {

            System.out.println("Login failed.");
            System.out.println("You cannot send messages.");

            input.close();
            return;
        }

        System.out.println(login.returnLoginStatus(
                username,
                password
        ));

        // Number of messages
        System.out.print(
                "How many messages would you like to enter? "
        );

        int numberOfMessages = input.nextInt();
        input.nextLine();

        int messagesEntered = 0;

        // Menu
        while (true) {

            System.out.println();
            System.out.println("-------------------------");
            System.out.println("QuickChat Menu");
            System.out.println("-------------------------");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Choose an option: ");

            int option = input.nextInt();
            input.nextLine();

            switch (option) {

                case 1:

                    if (messagesEntered >= numberOfMessages) {

                        System.out.println(
                                "You have already entered the "
                                + "maximum number of messages."
                        );

                        break;
                    }

                    // Recipient
                    System.out.print(
                            "Enter recipient cellphone number: "
                    );

                    String recipient = input.nextLine();

                    // Message
                    System.out.print(
                            "Enter your message: "
                    );

                    String messageText = input.nextLine();

                    message newMessage =
                            new message(recipient, messageText);

                    // Validate recipient
                    if (!newMessage.checkRecipientCell()) {

                        System.out.println(
                                "Invalid recipient cellphone number."
                        );

                        break;
                    }

                    // Validate message ID
                    if (!newMessage.checkMessageID()) {

                        System.out.println(
                                "Invalid message ID."
                        );

                        break;
                    }

                    // Create hash
                    newMessage.createMessageHash();

                    System.out.println();
                    System.out.println(
                            "Message ID: "
                            + newMessage.getMessageID()
                    );

                    System.out.println(
                            "Message Hash: "
                            + newMessage.getMessageHash()
                    );

                    System.out.println();
                    System.out.println("1) Send Message");
                    System.out.println("2) Disregard Message");
                    System.out.println("3) Store Message");

                    System.out.print("Choose an option: ");

                    int messageOption = input.nextInt();
                    input.nextLine();

                    if (messageOption == 1) {

                        System.out.println(
                                newMessage.SentMessage()
                        );

                        messagesEntered++;

                    } else if (messageOption == 2) {

                        System.out.println(
                                "Message disregarded."
                        );

                    } else if (messageOption == 3) {

                        System.out.println(
                                newMessage.storeMessage()
                        );

                        messagesEntered++;

                    } else {

                        System.out.println(
                                "Invalid option."
                        );
                    }

                    break;

                case 2:

                    System.out.println("Coming Soon.");
                    break;

                case 3:

                    System.out.println(
                            "Thank you for using QuickChat."
                    );

                    input.close();
                    return;

                default:

                    System.out.println(
                            "Invalid option. Please choose 1, 2 or 3."
                    );
            }
        }
    }
}