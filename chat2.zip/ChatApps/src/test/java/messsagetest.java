package za.ac.chatapps;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class messsage {

    @Test
    public void testCheckMessageID() {

        message msg = new message(
                "+27821234567",
                "Hello"
        );

        assertTrue(msg.checkMessageID());
    }

    @Test
    public void testCheckRecipientCell() {

        message msg = new message(
                "+27821234567",
                "Hello"
        );

        assertTrue(msg.checkRecipientCell());
    }

    @Test
    public void testCreateMessageHash() {

        message msg = new message(
                "+27821234567",
                "Hello"
        );

        String hash = msg.createMessageHash();

        assertNotNull(hash);
        assertFalse(hash.isEmpty());
    }

    @Test
    public void testSentMessage() {

        message msg = new message(
                "+27821234567",
                "Hello"
        );

        String result = msg.SentMessage();

        assertEquals(
                "Message successfully sent.",
                result
        );
    }

    @Test
    public void testReturnTotalMessages() {

        message msg = new message(
                "+27821234567",
                "Hello"
        );

        msg.SentMessage();

        assertTrue(msg.returnTotalMessages() > 0);
    }

    @Test
    public void testStoreMessage() {

        message msg = new message(
                "+27821234567",
                "Hello"
        );

        String result = msg.storeMessage();

        assertEquals(
                "Message successfully stored.",
                result
        );
    }
}