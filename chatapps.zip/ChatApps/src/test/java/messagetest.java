package za.ac.chatapps;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class messagetest {

    @Test
    public void testMessagePayload() {
        message msg = new message("Hello", "0821234567");
        assertEquals("Hello", msg.getMessagePayload());
    }

    @Test
    public void testRecipient() {
        message msg = new message("Hello", "0821234567");
        assertEquals("0821234567", msg.getRecipient());
    }

    @Test
    public void testMessageStartsAsNotSent() {
        message msg = new message("Hello", "0821234567");
        assertFalse(msg.isMessageSent());
    }

    @Test
    public void testMessageCanBeSent() {
        message msg = new message("Hello", "0821234567");
        msg.markAsSent();
        assertTrue(msg.isMessageSent());
    }

    @Test
    public void testMessageCanBeReceived() {
        message msg = new message("Hello", "0821234567");
        msg.markAsReceived();
        assertTrue(msg.isMessageReceived());
    }

    @Test
    public void testMessageCanBeRead() {
        message msg = new message("Hello", "0821234567");
        msg.markAsRead();
        assertTrue(msg.isMessageRead());
    }
}