package za.ac.chatapps;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Logintest{

    @Test
    public void testValidUsername() {
        Login login = new Login("siya_", "Password1!");
        assertTrue(login.checkUsername());
    }

    @Test
    public void testInvalidUsername() {
        Login login = new Login("siya", "Password1!");
        assertFalse(login.checkUsername());
    }

    @Test
    public void testValidPassword() {
        Login login = new Login("siya_", "Password1!");
        assertTrue(login.checkPassword());
    }

    @Test
    public void testInvalidPassword() {
        Login login = new Login("siya_", "password");
        assertFalse(login.checkPassword());
    }

    @Test
    public void testSuccessfulLogin() {
        Login login = new Login("siya_", "Password1!");
        assertTrue(login.login());
    }
}