package za.ac.chatapps;

import java.util.Scanner;

public class main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("====================================");
        System.out.println("          CHAT APPLICATION");
        System.out.println("====================================");

        // LOGIN
        System.out.println("\nLOGIN");

        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        Login login = new Login(username, password);

        if (!login.checkUsername()) {
            System.out.println("\nUsername is invalid.");
            System.out.println("Username must contain an underscore");
            System.out.println("and must not be longer than 5 characters.");

            scanner.close();
            return;
        }

        if (!login.checkPassword()) {
            System.out.println("\nPassword is invalid.");
            System.out.println("Password must contain at least 8 characters,");
            System.out.println("an uppercase letter, a number and a special character.");

            scanner.close();
            return;
        }

        System.out.println("\nLogin successful!");
        System.out.println("Welcome, " + username);

        // MESSAGE
        System.out.println("\n------------------------------------");
        System.out.println("             SEND MESSAGE");
        System.out.println("------------------------------------");

        System.out.print("Enter recipient: ");
        String recipient = scanner.nextLine();

        System.out.print("Enter message: ");
        String messageText = scanner.nextLine();

        Message message = new Message(messageText, recipient);

        // Send message
        message.markAsSent();

        System.out.println("\nMessage sent successfully.");

        System.out.println("\nMESSAGE DETAILS");
        System.out.println("------------------------------------");
        System.out.println("Recipient: " + message.getRecipient());
        System.out.println("Message: " + message.getMessagePayload());
        System.out.println("Sent: " + message.isMessageSent());
        System.out.println("Received: " + message.isMessageReceived());
        System.out.println("Read: " + message.isMessageRead());
        System.out.println("Status: " + message.getMessageStatus());

        // Demonstrate received status
        System.out.println("\nReceiving message...");
        message.markAsReceived();

        System.out.println("Status: " + message.getMessageStatus());

        // Demonstrate read status
        System.out.println("Reading message...");
        message.markAsRead();

        System.out.println("Status: " + message.getMessageStatus());

        System.out.println("\n====================================");
        System.out.println("        APPLICATION COMPLETE");
        System.out.println("====================================");

        scanner.close();
    }
}