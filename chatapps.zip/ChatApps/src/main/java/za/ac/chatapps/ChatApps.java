/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package za.ac.chatapps;

/**
 *
 * @author lulama
 */
public class ChatApps {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
