package za.ac.chatapps;

public class Login {

    private String username;
    private String password;

    public Login(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public boolean checkUsername() {
        return username != null
                && !username.isEmpty()
                && username.length() <= 5
                && username.contains("_");
    }

    public boolean checkPassword() {
        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasUppercase = false;
        boolean hasNumber = false;
        boolean hasSpecialCharacter = false;

        for (char character : password.toCharArray()) {

            if (Character.isUpperCase(character)) {
                hasUppercase = true;
            }

            if (Character.isDigit(character)) {
                hasNumber = true;
            }

            if (!Character.isLetterOrDigit(character)) {
                hasSpecialCharacter = true;
            }
        }

        return hasUppercase
                && hasNumber
                && hasSpecialCharacter;
    }

    public boolean login() {
        return checkUsername() && checkPassword();
    }
}