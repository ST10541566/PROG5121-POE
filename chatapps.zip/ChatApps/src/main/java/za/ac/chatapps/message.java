package za.ac.chatapps;

public class message {

    private String messagePayload;
    private String recipient;

    private boolean messageSent;
    private boolean messageReceived;
    private boolean messageRead;

    public message(String messagePayload, String recipient) {
        this.messagePayload = messagePayload;
        this.recipient = recipient;

        this.messageSent = false;
        this.messageReceived = false;
        this.messageRead = false;
    }

    public String getMessagePayload() {
        return messagePayload;
    }

    public String getRecipient() {
        return recipient;
    }

    public boolean isMessageSent() {
        return messageSent;
    }

    public boolean isMessageReceived() {
        return messageReceived;
    }

    public boolean isMessageRead() {
        return messageRead;
    }

    public void markAsSent() {
        messageSent = true;
    }

    public void markAsReceived() {
        messageReceived = true;
    }

    public void markAsRead() {
        messageRead = true;
    }

    public String getMessageStatus() {

        if (messageRead) {
            return "READ";
        }

        if (messageReceived) {
            return "RECEIVED";
        }

        if (messageSent) {
            return "SENT";
        }

        return "NOT SENT";
    }
}